@echo off
setlocal
title PyMacro Pad Installer
echo ======================================================
echo           Installing PyMacro Pad for Windows
echo ======================================================
echo.

set "INSTALL_DIR=%LOCALAPPDATA%\Programs\PyMacroPad"
echo [*] Target Directory: %INSTALL_DIR%

if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%"

echo [*] Copying application files...
copy /Y "%~dp0PyMacroPad.exe" "%INSTALL_DIR%\PyMacroPad.exe" >nul
if exist "%~dp0icon.ico" copy /Y "%~dp0icon.ico" "%INSTALL_DIR%\icon.ico" >nul

echo [*] Creating Desktop Shortcut...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ws = New-Object -ComObject WScript.Shell; $s = $ws.CreateShortcut([System.IO.Path]::Combine([Environment]::GetFolderPath('Desktop'), 'PyMacro Pad.lnk')); $s.TargetPath = '%INSTALL_DIR%\PyMacroPad.exe'; $s.WorkingDirectory = '%INSTALL_DIR%'; if (Test-Path '%INSTALL_DIR%\icon.ico') { $s.IconLocation = '%INSTALL_DIR%\icon.ico' }; $s.Save()"

echo [*] Creating Start Menu Shortcut...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ws = New-Object -ComObject WScript.Shell; $s = $ws.CreateShortcut([System.IO.Path]::Combine([Environment]::GetFolderPath('Programs'), 'PyMacro Pad.lnk')); $s.TargetPath = '%INSTALL_DIR%\PyMacroPad.exe'; $s.WorkingDirectory = '%INSTALL_DIR%'; if (Test-Path '%INSTALL_DIR%\icon.ico') { $s.IconLocation = '%INSTALL_DIR%\icon.ico' }; $s.Save()"

echo.
echo ======================================================
echo           Installation Completed Successfully!
echo ======================================================
echo [*] Shortcuts added to Desktop and Start Menu.
echo [*] Starting PyMacro Pad now...
start "" "%INSTALL_DIR%\PyMacroPad.exe"
echo.
pause
