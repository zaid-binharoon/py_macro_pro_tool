@echo off
setlocal
title PyMacro Pad Uninstaller
echo ======================================================
echo           Uninstalling PyMacro Pad
echo ======================================================
echo.

taskkill /F /IM PyMacroPad.exe >nul 2>&1

set "INSTALL_DIR=%LOCALAPPDATA%\Programs\PyMacroPad"
set "DESKTOP_LNK=%USERPROFILE%\Desktop\PyMacro Pad.lnk"
set "START_LNK=%APPDATA%\Microsoft\Windows\Start Menu\Programs\PyMacro Pad.lnk"

echo [*] Removing shortcuts...
if exist "%DESKTOP_LNK%" del /F /Q "%DESKTOP_LNK%" >nul 2>&1
if exist "%START_LNK%" del /F /Q "%START_LNK%" >nul 2>&1

echo [*] Removing application files...
if exist "%INSTALL_DIR%" rmdir /S /Q "%INSTALL_DIR%" >nul 2>&1

echo.
echo ======================================================
echo           PyMacro Pad has been uninstalled.
echo ======================================================
echo.
pause
