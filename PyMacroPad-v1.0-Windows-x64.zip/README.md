# 🐍 PyMacro Pad - Python Developer Productivity HUD

A lightweight, floating sticky-note macro pad for Windows designed to eliminate awkward keyboard gymnastics (like `Shift+9`, `Shift+1`, `Shift+5`, `Shift+8`, `Shift+=`) when writing Python code.

---

## ✨ Complete Hold-to-Type Mappings

Every single button on the macro pad now has its exact physical keyboard counterpart:

| Button | Key to Hold | Action | Description |
| :---: | :---: | :---: | :--- |
| **`()`** | **Hold `9`** | Types `()` | Places cursor inside: `(│)` |
| **`!=`** | **Hold `1`** | Types `!=` | Python inequality operator |
| **`""`** | **Hold `'`** | Types `""` | Places cursor inside: `"│"` |
| **`%`** | **Hold `5`** | Types `%` | Eliminates `Shift + 5` |
| **`*`** | **Hold `8`** *(or Numpad `*`)* | Types `*` | Eliminates `Shift + 8` |
| **`+`** | **Hold `=`** *(or Numpad `+`)* | Types `+` | Eliminates `Shift + =` |
| **`Jump Line`** | **Hold `Enter`** | Types `Ctrl + Enter` | Inserts clean new line below |

---

## 🛡️ Native Win32 Hard-Lock Protection

* **Zero Character Leaks:** When you hold any mapped key, the normal key is immediately blocked at the Windows kernel level. At ~250ms, **ONLY the symbol is typed**.
* **Complete Lock While Held:** While your finger remains pressed down on the key, **the key is 100% HARD-LOCKED**. All hardware auto-repeats from your laptop keyboard are suppressed. Absolutely nothing else can type while held.
* **Release to Unlock:** The key unlocks **only when you physically leave (release) the key**. The next character or symbol will only type when you press again.
* **Clean Tap:** Quickly tapping (<250ms) outputs a single normal character (`9`, `1`, `'`, `5`, `8`, `=`, `Enter`).
* **Fast Typing Rollover:** If you type fast (e.g. typing `50` or `19`), pending keys are flushed immediately in proper order.

---

## 🚀 Quick Start

### Run the Application
```powershell
python pymacro_pad.py
```
*(Or run `pythonw pymacro_pad.py` to run silently without keeping a black terminal open)*.
